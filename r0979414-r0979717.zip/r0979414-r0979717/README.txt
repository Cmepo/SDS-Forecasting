NeuralNetwork.py is not used, but it was the initial approach for the architecture.

Neural.py is the actual file used to make the prediction

main.py will execute DataValidation.py and Neural.py

Neural.py uses another CSV with values from https://energy-charts.info/charts/price_spot_market/chart.htm?l=en&c=BE&stacking=stacked_absolute_area&legendItems=010001&week=04 that has not been included. Therefore it is just commented.

